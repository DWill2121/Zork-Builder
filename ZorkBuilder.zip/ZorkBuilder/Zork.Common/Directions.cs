﻿namespace Zork
{
    public enum Directions
    {
        North,
        South,
        East,
        West
    } 
}