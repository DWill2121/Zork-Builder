﻿namespace InventoryManager.WinForms
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.OpenFile = new System.Windows.Forms.Label();
            this.SelectFileButton = new System.Windows.Forms.Button();
            this.FileNameTextBox = new System.Windows.Forms.TextBox();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.playersTabPage = new System.Windows.Forms.TabPage();
            this.addPlayersButton = new System.Windows.Forms.Button();
            this.deletePlayersButton = new System.Windows.Forms.Button();
            this.messageoftheDayLabel = new System.Windows.Forms.Label();
            this.DescriptionLabel = new System.Windows.Forms.Label();
            this.playerScoreLabel = new System.Windows.Forms.Label();
            this.MOTDTextBox = new System.Windows.Forms.TextBox();
            this.descriptionTextBox = new System.Windows.Forms.TextBox();
            this.roomNameTextBox = new System.Windows.Forms.TextBox();
            this.mainTabControl = new System.Windows.Forms.TabControl();
            this.neighborsTextBox = new System.Windows.Forms.TextBox();
            this.neighborsLabel = new System.Windows.Forms.Label();
            this.StartLocation = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.worldBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.roomsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.playersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.worldViewModelBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.saveData = new System.Windows.Forms.Button();
            this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.playersTabPage.SuspendLayout();
            this.mainTabControl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.worldBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.roomsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.worldViewModelBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // OpenFile
            // 
            this.OpenFile.AutoSize = true;
            this.OpenFile.Location = new System.Drawing.Point(28, 11);
            this.OpenFile.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.OpenFile.Name = "OpenFile";
            this.OpenFile.Size = new System.Drawing.Size(30, 17);
            this.OpenFile.TabIndex = 0;
            this.OpenFile.Text = "File";
            this.OpenFile.Click += new System.EventHandler(this.Label1_Click);
            // 
            // SelectFileButton
            // 
            this.SelectFileButton.Location = new System.Drawing.Point(747, 9);
            this.SelectFileButton.Margin = new System.Windows.Forms.Padding(4);
            this.SelectFileButton.Name = "SelectFileButton";
            this.SelectFileButton.Size = new System.Drawing.Size(41, 28);
            this.SelectFileButton.TabIndex = 1;
            this.SelectFileButton.Text = "...";
            this.SelectFileButton.UseVisualStyleBackColor = true;
            this.SelectFileButton.Click += new System.EventHandler(this.SelectFileButton_Click);
            // 
            // FileNameTextBox
            // 
            this.FileNameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.worldViewModelBindingSource, "Filename", true));
            this.FileNameTextBox.Location = new System.Drawing.Point(67, 11);
            this.FileNameTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.FileNameTextBox.Name = "FileNameTextBox";
            this.FileNameTextBox.ReadOnly = true;
            this.FileNameTextBox.Size = new System.Drawing.Size(671, 22);
            this.FileNameTextBox.TabIndex = 2;
            // 
            // openFileDialog
            // 
            this.openFileDialog.Filter = "World Files (*json)|*.json";
            this.openFileDialog.FileOk += new System.ComponentModel.CancelEventHandler(this.OpenFileDialog1_FileOk);
            // 
            // playersTabPage
            // 
            this.playersTabPage.Controls.Add(this.saveData);
            this.playersTabPage.Controls.Add(this.StartLocation);
            this.playersTabPage.Controls.Add(this.label1);
            this.playersTabPage.Controls.Add(this.neighborsTextBox);
            this.playersTabPage.Controls.Add(this.neighborsLabel);
            this.playersTabPage.Controls.Add(this.roomNameTextBox);
            this.playersTabPage.Controls.Add(this.descriptionTextBox);
            this.playersTabPage.Controls.Add(this.MOTDTextBox);
            this.playersTabPage.Controls.Add(this.playerScoreLabel);
            this.playersTabPage.Controls.Add(this.DescriptionLabel);
            this.playersTabPage.Controls.Add(this.messageoftheDayLabel);
            this.playersTabPage.Controls.Add(this.deletePlayersButton);
            this.playersTabPage.Controls.Add(this.addPlayersButton);
            this.playersTabPage.Location = new System.Drawing.Point(4, 25);
            this.playersTabPage.Margin = new System.Windows.Forms.Padding(4);
            this.playersTabPage.Name = "playersTabPage";
            this.playersTabPage.Padding = new System.Windows.Forms.Padding(4);
            this.playersTabPage.Size = new System.Drawing.Size(713, 435);
            this.playersTabPage.TabIndex = 0;
            this.playersTabPage.Text = "Zork";
            this.playersTabPage.UseVisualStyleBackColor = true;
            // 
            // addPlayersButton
            // 
            this.addPlayersButton.Location = new System.Drawing.Point(4, 400);
            this.addPlayersButton.Margin = new System.Windows.Forms.Padding(4);
            this.addPlayersButton.Name = "addPlayersButton";
            this.addPlayersButton.Size = new System.Drawing.Size(100, 28);
            this.addPlayersButton.TabIndex = 1;
            this.addPlayersButton.Text = "Add...";
            this.addPlayersButton.UseVisualStyleBackColor = true;
            this.addPlayersButton.Click += new System.EventHandler(this.AddPlayersButton_Click);
            // 
            // deletePlayersButton
            // 
            this.deletePlayersButton.Location = new System.Drawing.Point(119, 400);
            this.deletePlayersButton.Margin = new System.Windows.Forms.Padding(4);
            this.deletePlayersButton.Name = "deletePlayersButton";
            this.deletePlayersButton.Size = new System.Drawing.Size(100, 28);
            this.deletePlayersButton.TabIndex = 2;
            this.deletePlayersButton.Text = "Delete";
            this.deletePlayersButton.UseVisualStyleBackColor = true;
            this.deletePlayersButton.Click += new System.EventHandler(this.DeletePlayersButton_Click);
            // 
            // messageoftheDayLabel
            // 
            this.messageoftheDayLabel.AutoSize = true;
            this.messageoftheDayLabel.Location = new System.Drawing.Point(8, 4);
            this.messageoftheDayLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.messageoftheDayLabel.Name = "messageoftheDayLabel";
            this.messageoftheDayLabel.Size = new System.Drawing.Size(134, 17);
            this.messageoftheDayLabel.TabIndex = 7;
            this.messageoftheDayLabel.Text = "Message of the Day";
            this.messageoftheDayLabel.Click += new System.EventHandler(this.PlayerNameLabel_Click);
            // 
            // DescriptionLabel
            // 
            this.DescriptionLabel.AutoSize = true;
            this.DescriptionLabel.Location = new System.Drawing.Point(8, 98);
            this.DescriptionLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.DescriptionLabel.Name = "DescriptionLabel";
            this.DescriptionLabel.Size = new System.Drawing.Size(79, 17);
            this.DescriptionLabel.TabIndex = 9;
            this.DescriptionLabel.Text = "Description";
            this.DescriptionLabel.Click += new System.EventHandler(this.playerHealthLabel_Click);
            // 
            // playerScoreLabel
            // 
            this.playerScoreLabel.AutoSize = true;
            this.playerScoreLabel.Location = new System.Drawing.Point(8, 64);
            this.playerScoreLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.playerScoreLabel.Name = "playerScoreLabel";
            this.playerScoreLabel.Size = new System.Drawing.Size(49, 17);
            this.playerScoreLabel.TabIndex = 11;
            this.playerScoreLabel.Text = "Room:";
            // 
            // MOTDTextBox
            // 
            this.MOTDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.playersBindingSource, "MessageoftheDay", true));
            this.MOTDTextBox.Location = new System.Drawing.Point(8, 25);
            this.MOTDTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.MOTDTextBox.Name = "MOTDTextBox";
            this.MOTDTextBox.Size = new System.Drawing.Size(697, 22);
            this.MOTDTextBox.TabIndex = 8;
            this.MOTDTextBox.TextChanged += new System.EventHandler(this.NameTextBox_TextChanged);
            // 
            // descriptionTextBox
            // 
            this.descriptionTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.roomsBindingSource, "Description", true));
            this.descriptionTextBox.Location = new System.Drawing.Point(11, 119);
            this.descriptionTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.descriptionTextBox.Multiline = true;
            this.descriptionTextBox.Name = "descriptionTextBox";
            this.descriptionTextBox.Size = new System.Drawing.Size(694, 229);
            this.descriptionTextBox.TabIndex = 10;
            // 
            // roomNameTextBox
            // 
            this.roomNameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.roomsBindingSource, "Name", true));
            this.roomNameTextBox.Location = new System.Drawing.Point(61, 64);
            this.roomNameTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.roomNameTextBox.Name = "roomNameTextBox";
            this.roomNameTextBox.Size = new System.Drawing.Size(271, 22);
            this.roomNameTextBox.TabIndex = 12;
            // 
            // mainTabControl
            // 
            this.mainTabControl.Controls.Add(this.playersTabPage);
            this.mainTabControl.Location = new System.Drawing.Point(67, 43);
            this.mainTabControl.Margin = new System.Windows.Forms.Padding(4);
            this.mainTabControl.Name = "mainTabControl";
            this.mainTabControl.SelectedIndex = 0;
            this.mainTabControl.Size = new System.Drawing.Size(721, 464);
            this.mainTabControl.TabIndex = 3;
            this.mainTabControl.SelectedIndexChanged += new System.EventHandler(this.MainTabControl_SelectedIndexChanged);
            // 
            // neighborsTextBox
            // 
            this.neighborsTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.roomsBindingSource, "Neighbors", true));
            this.neighborsTextBox.Location = new System.Drawing.Point(93, 370);
            this.neighborsTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.neighborsTextBox.Name = "neighborsTextBox";
            this.neighborsTextBox.Size = new System.Drawing.Size(544, 22);
            this.neighborsTextBox.TabIndex = 14;
            // 
            // neighborsLabel
            // 
            this.neighborsLabel.AutoSize = true;
            this.neighborsLabel.Location = new System.Drawing.Point(8, 370);
            this.neighborsLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.neighborsLabel.Name = "neighborsLabel";
            this.neighborsLabel.Size = new System.Drawing.Size(77, 17);
            this.neighborsLabel.TabIndex = 13;
            this.neighborsLabel.Text = "Neighbors:";
            // 
            // StartLocation
            // 
            this.StartLocation.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.playersBindingSource, "StartingLocation", true));
            this.StartLocation.Location = new System.Drawing.Point(444, 64);
            this.StartLocation.Margin = new System.Windows.Forms.Padding(4);
            this.StartLocation.Name = "StartLocation";
            this.StartLocation.Size = new System.Drawing.Size(261, 22);
            this.StartLocation.TabIndex = 16;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(340, 64);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 17);
            this.label1.TabIndex = 15;
            this.label1.Text = "Start Location";
            // 
            // worldBindingSource
            // 
            this.worldBindingSource.DataMember = "World";
            this.worldBindingSource.DataSource = this.worldViewModelBindingSource;
            // 
            // roomsBindingSource
            // 
            this.roomsBindingSource.DataMember = "Rooms";
            this.roomsBindingSource.DataSource = this.worldBindingSource;
            // 
            // playersBindingSource
            // 
            this.playersBindingSource.DataMember = "Players";
            this.playersBindingSource.DataSource = this.worldBindingSource;
            // 
            // worldViewModelBindingSource
            // 
            this.worldViewModelBindingSource.DataSource = typeof(InventoryManager.WinForms.ViewModels.WorldViewModel);
            // 
            // saveData
            // 
            this.saveData.Location = new System.Drawing.Point(232, 400);
            this.saveData.Margin = new System.Windows.Forms.Padding(4);
            this.saveData.Name = "saveData";
            this.saveData.Size = new System.Drawing.Size(100, 28);
            this.saveData.TabIndex = 17;
            this.saveData.Text = "Save";
            this.saveData.UseVisualStyleBackColor = true;
            this.saveData.Click += new System.EventHandler(this.saveData_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(804, 522);
            this.Controls.Add(this.mainTabControl);
            this.Controls.Add(this.FileNameTextBox);
            this.Controls.Add(this.SelectFileButton);
            this.Controls.Add(this.OpenFile);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MinimizeBox = false;
            this.Name = "MainForm";
            this.Text = "Inventory Manager";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.playersTabPage.ResumeLayout(false);
            this.playersTabPage.PerformLayout();
            this.mainTabControl.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.worldBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.roomsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.worldViewModelBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label OpenFile;
        private System.Windows.Forms.Button SelectFileButton;
        private System.Windows.Forms.TextBox FileNameTextBox;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.TabPage playersTabPage;
        private System.Windows.Forms.TextBox roomNameTextBox;
        private System.Windows.Forms.TextBox descriptionTextBox;
        private System.Windows.Forms.TextBox MOTDTextBox;
        private System.Windows.Forms.Label playerScoreLabel;
        private System.Windows.Forms.Label DescriptionLabel;
        private System.Windows.Forms.Label messageoftheDayLabel;
        private System.Windows.Forms.Button deletePlayersButton;
        private System.Windows.Forms.Button addPlayersButton;
        private System.Windows.Forms.TabControl mainTabControl;
        private System.Windows.Forms.TextBox neighborsTextBox;
        private System.Windows.Forms.Label neighborsLabel;
        private System.Windows.Forms.TextBox StartLocation;
        private System.Windows.Forms.BindingSource worldViewModelBindingSource;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.BindingSource worldBindingSource;
        private System.Windows.Forms.BindingSource roomsBindingSource;
        private System.Windows.Forms.BindingSource playersBindingSource;
        private System.Windows.Forms.Button saveData;
        private System.Windows.Forms.SaveFileDialog saveFileDialog;
    }
}

