﻿using System;
using System.Collections.Generic;
using System.ComponentModel;

namespace InventoryManager.Data
{
    public class Player : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        public string StartingLocation { get; set; }
        public string MessageoftheDay { get; set; }





    }
}
